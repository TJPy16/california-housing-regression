from statistics import LinearRegression
from sklearn.model_selection import GridSearchCV, train_test_split
from sklearn.metrics import classification_report, accuracy_score, r2_score, root_mean_squared_error
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
from sklearn.datasets import fetch_california_housing
import pandas as pd
import matplotlib.pyplot as plt

house = fetch_california_housing()
x,y = house.data, house.target

x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=42)

model = RandomForestRegressor()

param_grid = {
    'n_estimators': [50,100],
    'max_depth': [10, None],
    'min_samples_split': [2,4]
}

grid = GridSearchCV(model, param_grid, cv=5)
grid.fit(x_train, y_train)

y_pred = grid.best_estimator_.predict(x_test)

#print(y_pred)
print(grid.best_params_)
print('R2:', r2_score(y_test, y_pred))
print('RMSE:', root_mean_squared_error(y_test, y_pred))

plt.scatter(y_test, y_pred, alpha=0.5)
plt.xlabel('Actual')
plt.ylabel('Predicted')
plt.title('Actual vs Predicted')
plt.show()




